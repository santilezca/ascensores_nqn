---
name: Vertical Precision
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#271901'
  on-tertiary-container: '#98805d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#fcdeb5'
  tertiary-fixed-dim: '#dec29a'
  on-tertiary-fixed: '#271901'
  on-tertiary-fixed-variant: '#574425'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  gutter: 24px
  margin-desktop: 80px
  margin-mobile: 20px
  max-width: 1280px
---

## Brand & Style

The brand identity centers on the concept of "Precision in Motion." It reflects the engineering excellence, safety, and reliability required in the vertical transportation industry. The target audience includes property developers, building managers, and high-end residential owners in the Neuquén region who value technical expertise and seamless service.

The design system adopts a **Corporate / Modern** style with a **High-End Industrial** edge. It utilizes a structured grid, generous whitespace, and sharp execution to evoke an emotional response of absolute trust and architectural sophistication. Visual elements should feel structural—anchored by strong vertical lines and a sense of upward momentum.

## Colors

The palette is rooted in industry and stability. 

- **Primary (Midnight Navy):** Used for core branding, typography, and deep backgrounds to establish authority and trust.
- **Secondary (Steel Grey):** Represents the raw materials of the trade. Used for borders, subtle backgrounds, and secondary information.
- **Accent (Safety Orange):** A high-visibility hue reserved strictly for Calls to Action (CTAs), critical alerts, and directional indicators.
- **Neutral (Cloud White):** Provides a clean, sterile environment that allows the industrial tones to feel premium rather than heavy.

The default color mode is **Light**, ensuring maximum readability for technical documentation and service forms.

## Typography

This design system utilizes **Inter** exclusively to leverage its systematic, utilitarian, and highly legible characteristics. 

- **Display & Headlines:** Use tight letter spacing and bold weights to mimic architectural signage.
- **Body Text:** Maintains a standard weight with generous line height to ensure clarity in maintenance logs and service descriptions.
- **Labels:** Set in semi-bold uppercase with increased letter spacing for a technical, "blueprinted" aesthetic. These are used for technical specs and category tags.

## Layout & Spacing

The layout is built on a **12-column fluid grid** for desktop and a **4-column grid** for mobile. 

- **Vertical Rhythm:** All spacing must be a multiple of the 8px base unit. 
- **Grid Logic:** Use a fixed max-width for content containers to maintain a premium, controlled feel.
- **Responsiveness:** On mobile, margins reduce significantly to maximize screen real estate for forms and lists, while gutters remain constant at 24px to prevent visual clutter.
- **Sectioning:** Large vertical gaps (80px–120px) should separate major content blocks to evoke a sense of height and "room to move," mirroring the lift shafts themselves.

## Elevation & Depth

To maintain a "high-end industrial" feel, the system avoids heavy, organic shadows. Instead, it uses **Tonal Layers** and **Low-Contrast Outlines**.

- **Level 0 (Base):** Neutral white background.
- **Level 1 (Cards/Surface):** A subtle 1px border in Steel Grey (`#E2E8F0`) with no shadow.
- **Level 2 (Interaction/Hover):** A very soft, large-radius ambient shadow (0px 10px 30px rgba(15, 23, 42, 0.05)) to suggest a slight lift.
- **Sticky Elements:** The navigation bar uses a high-density backdrop blur (20px) with a semi-transparent white fill (90% opacity) to maintain context while scrolling.

## Shapes

The shape language is **Soft (0.25rem)**. This subtle rounding suggests precision engineering—not sharp or dangerous, but not overly playful or consumer-grade.

- **Buttons & Inputs:** Use the standard 0.25rem (4px) radius.
- **Cards:** May use a slightly larger radius (8px) to soften the industrial palette.
- **Icons:** Should be encased in square containers with the same radius to maintain a modular, technical appearance.

## Components

### Buttons
- **Primary:** Solid Midnight Navy with White text. Square-ish but with the 4px radius.
- **CTA:** Solid Safety Orange. Used exclusively for "Request Quote" or "Emergency Service."
- **Secondary:** Ghost style with a Steel Grey border and Navy text.

### Navigation
- **Sticky Header:** Compact height (72px). Features a prominent Navy logo on the left and the Orange CTA on the far right. Use a bottom border of 1px Steel Grey for definition.

### Grid Cards
- Used for "Services" and "Project Gallery." Cards include a Steel Grey icon in the top left, a Headline-sm, and Body-md text. On hover, the border color shifts to Midnight Navy.

### Horizontal Steppers
- Used for the "Installation Process." Connected by a thin 2px Steel Grey line. Active steps are filled with Midnight Navy; completed steps feature a Safety Orange checkmark.

### Trust Banners
- Full-width, low-contrast Grey background (`#F1F5F9`). Contains grayscale logos of certifications or regional partners, emphasizing the "SRL" and local Neuquén roots.

### Input Fields
- High-contrast 1px borders. Focused states use a 2px Midnight Navy border. Error states use a 1px Red border with a small supporting text label in `label-sm`.